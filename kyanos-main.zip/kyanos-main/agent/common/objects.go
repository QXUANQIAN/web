package common

import "github.com/cilium/ebpf"

var CollectionOpts *ebpf.CollectionOptions
