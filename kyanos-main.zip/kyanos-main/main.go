package main

import "kyanos/cmd"

func main() {
	cmd.Execute()
}
