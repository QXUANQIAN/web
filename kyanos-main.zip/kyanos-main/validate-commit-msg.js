'use strict';

module.exports = require('./lib/validateMessage').validateMessage;